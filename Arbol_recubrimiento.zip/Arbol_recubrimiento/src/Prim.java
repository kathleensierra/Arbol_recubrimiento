
public class Prim {
    
    

    static final int INF = 999999;

    public static void prim(int[][] grafo) {

        int n = grafo.length;

        // Guarda el vértice que ya pertenece al árbol
        boolean[] visitado = new boolean[n];

        // Guarda el costo mínimo para llegar a cada vértice
        int[] costo = new int[n];

        // Guarda de qué vértice viene cada conexión
        int[] padre = new int[n];

        // Inicializamos
        for (int i = 0; i < n; i++) {
            costo[i] = INF;
            padre[i] = -1;
        }

        // Comenzamos desde el vértice A
        costo[0] = 0;

        int costoTotal = 0;

        System.out.println("ARBOL DE RECUBRIMIENTO MINIMO");
        System.out.println("--------------------------------");

        for (int i = 0; i < n; i++) {

            // Buscar el vértice con menor costo
            int u = -1;

            for (int j = 0; j < n; j++) {
                if (!visitado[j] && (u == -1 || costo[j] < costo[u])) {
                    u = j;
                }
            }

            // Marcamos el vértice como visitado
            visitado[u] = true;

            // Si no es el primer vértice, mostramos la conexión
            if (padre[u] != -1) {

                System.out.println(
                    (char)('A' + padre[u]) + " - "
                    + (char)('A' + u)
                    + " = " + grafo[padre[u]][u]
                );

                costoTotal += grafo[padre[u]][u];
            }

            // Actualizamos los costos de los vecinos
            for (int v = 0; v < n; v++) {

                if (grafo[u][v] != 0 &&
                    !visitado[v] &&
                    grafo[u][v] < costo[v]) {

                    costo[v] = grafo[u][v];
                    padre[v] = u;
                }
            }
        }

        System.out.println("--------------------------------");
        System.out.println("Costo total = " + costoTotal);
    }

    public static void main(String[] args) {

        /*
         A  B  C  D  E  F
        */

        int[][] grafo = {

            // A  B  C  D  E  F
            { 0, 4, 3, 0, 0, 0 }, // A
            { 4, 0, 2, 5, 0, 0 }, // B
            { 3, 2, 0, 7, 8, 0 }, // C
            { 0, 5, 7, 0, 6, 4 }, // D
            { 0, 0, 8, 6, 0, 5 }, // E
            { 0, 0, 0, 4, 5, 0 }  // F
        };

        prim(grafo);
    }
}
    

